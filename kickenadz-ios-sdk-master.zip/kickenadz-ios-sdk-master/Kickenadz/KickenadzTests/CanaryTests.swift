//
//  CanaryTests.swift
//  kickenadz
//
//  Created by Ryuichi Saito on 12/14/16.
//  Copyright © 2016 kickenadz. All rights reserved.
//

import XCTest

class CanaryTests: XCTestCase {
    func testCanary() {
        XCTAssertTrue(true)
    }
}
