//
//  kickenadz.h
//  kickenadz
//
//  Created by Ryuichi Saito on 11/8/16.
//  Copyright © 2016 kickenadz. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for kickenadz.
FOUNDATION_EXPORT double kickenadzVersionNumber;

//! Project version string for kickenadz.
FOUNDATION_EXPORT const unsigned char kickenadzVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <kickenadz/PublicHeader.h>


