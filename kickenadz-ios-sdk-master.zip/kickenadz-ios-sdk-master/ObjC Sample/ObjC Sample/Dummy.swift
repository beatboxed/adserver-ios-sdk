//
//  Dummy.swift
//  ObjC Sample
//
//  Created by Ryuichi Saito on 11/8/16.
//  Copyright © 2016 kickenadz. All rights reserved.
//

import Foundation
