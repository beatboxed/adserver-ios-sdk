//
//  ViewController.h
//  ObjC Sample
//
//  Created by Ryuichi Saito on 11/8/16.
//  Copyright © 2016 kickenadz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

